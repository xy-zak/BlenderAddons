import bpy
from bpy.props import StringProperty, IntProperty, BoolProperty, FloatProperty
from bpy.types import PropertyGroup

# Server settings
class ServerSettings(PropertyGroup):
    ip_address: StringProperty(
        name="IP Address",
        description="IP Address to bind WebSocket server to",
        default="0.0.0.0"
    )
    
    port: IntProperty(
        name="Port",
        description="Port to listen for WebSocket messages",
        default=8765,
        min=1024,
        max=65535
    )
    
    esp_connected: BoolProperty(
        name="ESP Connected",
        description="Indicates if an ESP client is connected",
        default=False
    )
    
    esp_ip: StringProperty(
        name="ESP IP Address",
        description="IP Address of the connected ESP",
        default=""
    )

# Debug information
class DebugSettings(PropertyGroup):
    show_debug: BoolProperty(
        name="Show Debug Info",
        description="Show WebSocket debug information",
        default=True
    )
    
    last_message: StringProperty(
        name="Last Message",
        default="None"
    )
    
    connection_status: StringProperty(
        name="Connection Status",
        default="Disconnected"
    )
    
    message_log: StringProperty(
        name="Message Log",
        description="Log of recent messages",
        default=""
    )
    
    # Debug simulation settings - renamed to simulation
    debug_mode: BoolProperty(
        name="Enable Simulation",
        description="Enable simulation tools for testing without ESP32",
        default=True
    )
    
    debug_simulation_active: BoolProperty(
        name="Simulation Active",
        description="Indicates if simulation is running",
        default=False
    )
    
    require_hybrid: BoolProperty(
        name="Require Hybrid Setup",
        description="If enabled, simulation tools will only work with hybrid camera setup",
        default=False
    )

# Camera tracking settings
class CameraTrackingSettings(PropertyGroup):
    target_camera: StringProperty(
        name="Target Camera",
        description="Camera to control with IMU data",
        default=""
    )
    
    target_empty: StringProperty(
        name="Target Empty",
        description="Empty parent of the target camera",
        default=""
    )
    
    track_rotation: BoolProperty(
        name="Track Rotation",
        description="Apply rotation data from IMU to the camera",
        default=True
    )
    
    track_location: BoolProperty(
        name="Track Location",
        description="Apply location data from IMU to the camera",
        default=True
    )
    
    rotation_factor: FloatProperty(
        name="Rotation Factor",
        description="Multiplier for rotation values",
        default=1.0,
        min=0.01,
        max=10.0
    )
    
    location_factor: FloatProperty(
        name="Location Factor",
        description="Multiplier for location values",
        default=1.0,
        min=0.01, 
        max=10.0
    )
    
    # Empty location properties
    empty_loc_x: FloatProperty(
        name="X",
        description="X location of the empty parent",
        default=0.0,
        update=lambda self, context: update_empty_location(self, context)
    )
    
    empty_loc_y: FloatProperty(
        name="Y",
        description="Y location of the empty parent",
        default=0.0,
        update=lambda self, context: update_empty_location(self, context)
    )
    
    empty_loc_z: FloatProperty(
        name="Z",
        description="Z location of the empty parent",
        default=0.0,
        update=lambda self, context: update_empty_location(self, context)
    )
    
    # Rotation offset properties (new)
    rotation_offset_x: FloatProperty(
        name="X Offset",
        description="X rotation offset applied to camera (degrees)",
        default=0.0,
        subtype='ANGLE',
        unit='ROTATION'
    )
    
    rotation_offset_y: FloatProperty(
        name="Y Offset",
        description="Y rotation offset applied to camera (degrees)",
        default=0.0,
        subtype='ANGLE',
        unit='ROTATION'
    )
    
    rotation_offset_z: FloatProperty(
        name="Z Offset",
        description="Z rotation offset applied to camera (degrees)",
        default=0.0,
        subtype='ANGLE',
        unit='ROTATION'
    )
    
    last_imu_data: StringProperty(
        name="Last IMU Data",
        default="{}"
    )

# Function to update empty location when properties change
def update_empty_location(self, context):
    """Update the empty's location when properties change"""
    if hasattr(self, 'target_empty') and self.target_empty:
        try:
            if self.target_empty in bpy.data.objects:
                empty = bpy.data.objects[self.target_empty]
                empty.location.x = self.empty_loc_x
                empty.location.y = self.empty_loc_y
                empty.location.z = self.empty_loc_z
        except:
            # Silently fail - this prevents errors in the UI
            pass

# Register all property groups
def register():
    bpy.utils.register_class(ServerSettings)
    bpy.utils.register_class(DebugSettings)
    bpy.utils.register_class(CameraTrackingSettings)
    
    bpy.types.Scene.server_settings = bpy.props.PointerProperty(type=ServerSettings)
    bpy.types.Scene.debug_settings = bpy.props.PointerProperty(type=DebugSettings)
    bpy.types.Scene.camera_tracking = bpy.props.PointerProperty(type=CameraTrackingSettings)

# Unregister all property groups
def unregister():
    del bpy.types.Scene.server_settings
    del bpy.types.Scene.debug_settings
    del bpy.types.Scene.camera_tracking
    
    bpy.utils.unregister_class(CameraTrackingSettings)
    bpy.utils.unregister_class(DebugSettings)
    bpy.utils.unregister_class(ServerSettings)