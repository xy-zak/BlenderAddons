from . import main_panel

def register():
    main_panel.register()

def unregister():
    main_panel.unregister()